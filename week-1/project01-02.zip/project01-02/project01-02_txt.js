/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: Shannon Kueneke
    Date: August 11, 2025

    Filename: project01-02.js
*/

//define variables for service name and service speed
service1Name = "Basic", service2Name = "Express", service3Name = "Extreme", service4Name = "Ultimate", service1Speed = "50 Mbsp", service2Speed = "100 Mbsp", service3Speed = "500 Mbsp", service4Speed = "1 Gig";